﻿# Test - Build - Submit

## Test

You should put some instrcutions on how to test your app here
  > **Note:** Looking for some debugging tools that work on all your platforms? Try [Vorlon.js](http://www.vorlonjs.com/). It makes mobile testing a breeze, and works inside the app ManifoldJS apps.

## Submit to Store

show where you  can submit the app, any additional packaging steps and anything else that they will need to know to get into store
